package com.javaedu;

import java.util.Scanner;

class Smallest{
	int arr[];
	int size;
	
	void inputData() {
		System.out.println("Enter size of array:");
		Scanner sc=new Scanner(System.in);
		size=sc.nextInt();
		
		arr=new int[size];
		System.out.println("Enter "+size+" elements for array:");
		for(int i=0;i<size;i++) {
			arr[i]=sc.nextInt();
		}
		
	}
	void findSmallAndDisplay() {
		int min=arr[0];
		for(int i=0;i<size;i++) {
			if(arr[i]<min) {
				min=arr[i];
			}
		}
		System.out.println("Smallest element of array: "+min);
	}
}
public class SmallestOfArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Smallest sm=new Smallest();
		sm.inputData();
		sm.findSmallAndDisplay();
		
		
		
	}

}
