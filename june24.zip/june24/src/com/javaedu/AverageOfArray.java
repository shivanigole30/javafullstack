package com.javaedu;

import java.util.Scanner;

class Average{
	int arr[];
	int size;
	int sum=0;
	
	
	
	void inputData() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Size of Array:");
		size=sc.nextInt();
		
		arr=new int[size];
		System.out.println("Enter "+size+" elements of array:");
		for(int i=0;i<size;i++) {
			arr[i]=sc.nextInt();
		}
	}
		void sumDisplay() {
			for(int i=0;i<size;i++) {
				sum=sum+arr[i];
			}
			System.out.println("Sum is:"+sum);
		}
	
	void avg() {
		float avg=(float)sum/size;
		System.out.println("Average of "+size+" Elements is:"+avg);
}
}
public class AverageOfArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Average avg=new Average();
		avg.inputData();
		avg.sumDisplay();
		avg.avg();
		
		
		
	}

}
