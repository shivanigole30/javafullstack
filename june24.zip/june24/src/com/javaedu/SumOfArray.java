package com.javaedu;

import java.util.Scanner;

public class SumOfArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[];
		int size;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enetr size:");
		 size=sc.nextInt();
		 arr=new int[size];
		 System.out.println("enter "+size+" elements");
		 for(int i=0;i<size;i++) {
			 arr[i]=sc.nextInt();
			 
		 }
		 int sum=0;
		 for(int i=0;i<size;i++) {
			  sum= sum+arr[i];
		 }
		System.out.println("Sum of elements:"+sum);
	}

}
