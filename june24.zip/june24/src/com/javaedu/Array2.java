//declaration, initialization
package com.javaedu;

import java.util.Scanner;

public class Array2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int ar[]=new int[6];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter "+ar.length+" of elements");
		for(int i=0;i<ar.length;i++) {
			ar[i]=sc.nextInt();
			
		}
		System.out.println("Array elements are:");
		for(int i:ar) {
			System.out.println(i);
		}
	}

}
