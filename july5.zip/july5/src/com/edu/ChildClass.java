//static final demonstration
package com.edu;
 class MyClass{
	final void finalMethod() {
		System.out.println("Final method");
	}
	static void staticMethod() {
		System.out.println("parent class static method");
	}
	void normalMethod() {
		System.out.println("parent normal method");
	}
}
public class ChildClass extends MyClass {

//	final void finalMethod() {  cannot override final method in the child class
//		System.out.println("Final method");
//	}
	static void staticMethod() {
//		super.staticMethod(); static method cannot be overridden 
		System.out.println("child class static method");
	}
	void normalMethod() {
		super.normalMethod();
		System.out.println("child normal method");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ChildClass ob=new ChildClass();
		ob.finalMethod();
		ob.staticMethod();
		ChildClass.staticMethod();
		MyClass.staticMethod();
		ob.normalMethod();
		
	}

}
