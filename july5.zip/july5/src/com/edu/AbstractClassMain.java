package com.edu;
abstract class  MyAbstractClass{
	private int pdata;
	public MyAbstractClass(int pdata) {
		System.out.println(pdata+10);
	}
}
class Child1  extends MyAbstractClass {
	public Child1(int pdata) {
		super(pdata);
	}
}
public class AbstractClassMain{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Child1 obj=new Child1(45);
	}

}
