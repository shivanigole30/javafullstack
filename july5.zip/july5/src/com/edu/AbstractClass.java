package com.edu;

abstract class MyAbstract{
	
	void display() {
		System.out.println("Display Method");
	}
}
public class AbstractClass extends MyAbstract {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		MyAbstract obj=new MyAbstract(); {
			
		AbstractClass absobj =new AbstractClass();
		
		absobj.display();
		}
	}


