//public - package to package it is visible 
//default- with in package all the class can access with object ref
//         other package default cannot be accessed (default becomes private)
//protected- with in package it behaves like default another package only child class can access
//private- visibility is within class
package p1;

import p2.ClassMain;

public class AccessModifierMain extends ClassMain {
public int publicval;
protected int protectedval;
private int privateval;
int defaultval;

public AccessModifierMain() {
	// TODO Auto-generated constructor stub
	publicval=10;
	protectedval=20;
	defaultval=30;
	privateval=40;
}
public void display() {
	System.out.println("Hello from package p1");
}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AccessModifierMain obj1=new AccessModifierMain();
		System.out.println(obj1.privateval); //private value can access within the class
		AccessModifier obj2=new AccessModifier();
		obj2.show();
		
		obj2.display2(); //protected method from access modifier class
		
		obj1.sum(); // accessing protected method from ClassMain p2 package 
		
	}

}
