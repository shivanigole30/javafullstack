package com.javaedu;

import java.util.Scanner;

public class VoteIf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name;
		int age;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your name:");
		 name=sc.nextLine();
		 System.out.println("Enter your age:");
		 age=sc.nextInt();
		 
		 if(age>=18) {
			 System.out.println(name+" You Can Vote");
		 }
		 else {
			 System.out.println(name+" You Cannot Vote");
		 }
		 
	}

}
