package com.javaedu;

import java.util.Scanner;

class LinearSearchElementEx2{
	int arr[],size,key;
	
	void inputData() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Array Size: ");
		size=sc.nextInt();
		arr=new int[size];
		
		System.out.println("Enter array elements: ");
		for(int i=0;i<size;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter Element to search: ");
		key=sc.nextInt();
	}
	
	void display() {
		System.out.println("Array Elements are:");
		for(int i=0;i<size;i++) {
			System.out.println(arr[i]);
		}
	}
	
	void linearSearch() {
		int pos=-1;
		for(int i=0;i<size;i++) {
			if(key==arr[i]) {
				pos=i;
				break;
			}
			
		}
		if(pos>=0) {
			System.out.println("Successful Search");
			System.out.println(key+" found at position "+(pos+1));
		}
		else {
			System.out.println("Unsuccessful Search");
			System.out.println("Not found");
		}
	}
}
public class LinearSearchEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinearSearchElementEx2 lobj=new LinearSearchElementEx2();
		lobj.inputData();
		lobj.display();
		lobj.linearSearch();
	}

}
