package com.user.statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class InsertOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String driver="com.mysql.cj.jdbc.Driver"; //Driver class
		String url="jdbc:mysql://localhost:3306/shivani";
		String un="root";
		String up="root";
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		int sid;
		String sn;
		float fs;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter student name");
		sn=sc.next();
		System.out.println("Enter Student id");
		sid=sc.nextInt();
		System.out.println("Enter student fees");
		fs=sc.nextFloat();
		
		try {

			Class.forName(driver); //load the driver at run time, register 
			conn = DriverManager.getConnection(url,un,up); //create the connection
			st=conn.createStatement(); //Creating statement
			//System.out.println(conn);
			//check record exists
			String sel="select * from shivanitable where id="+sid;
			rs=st.executeQuery(sel);
			if(rs.next()){
				System.out.println(sid+" already exists");
			}else {
			
			
			String ins="insert into shivanitable values("+sid+",'"+sn+"',"+fs+")";
			System.out.println(ins);
			int rval=st.executeUpdate(ins);//for insert , update and delete use exceuteUpdate
			if(rval>0) {
				System.out.println("Record is added");
			}
			else {
				System.out.println("Error Occurred");
			}
			}
			
	}catch(Exception e) {
		e.printStackTrace();
	}


		}
		
		
	}


