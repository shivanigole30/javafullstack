package com.user.statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class UpdateOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String driver ="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/shivani";
		String un="root";
		String up="root";
		ResultSet rs=null;
		Statement st=null;
		Connection conn=null;
		String n;
		int stid;
		Scanner sc=new Scanner(System.in);
		
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			st=conn.createStatement();
			System.out.println("Enter name to be changed");
			n=sc.nextLine();
			System.out.println("Enter student id:");
			stid=sc.nextInt();
			//check id exists for updating record
			
			String sel="select * from shivanitable where Id="+stid;
			rs=st.executeQuery(sel);
			if(rs.next()) {
				String upd="update shivanitable set name='"+n+"' where Id ="+stid;
				int retval=st.executeUpdate(upd);
				if(retval>0) {
					System.out.println("student changed successfully");
				}else {
					System.out.println("error!!!");
				}
			}else {
				System.out.println(stid+" not exists for updating record");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	}


