package com.user.statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;



public class SelectJdbcOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/shivani";
		String un="root";
		String up="root";
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			st=conn.createStatement();
			System.out.println(conn);
			String sel="select * from shivanitable";
			rs=st.executeQuery(sel);
			System.out.println(rs);
			System.out.println("id\tname\tfees");
			
			while(rs.next()) {
				int sid=rs.getInt(1);
				String sname=rs.getString(2);
				
				float fs=rs.getFloat(3);
				System.out.println(sid+"\t"+sname+"\t"+fs);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}


		
	}


