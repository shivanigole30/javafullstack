package com.user.statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String driver ="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/shivani";
		String un="root";
		String up="root";
		int sid;
		Statement st=null;
		Connection conn=null;
		ResultSet rs=null;
		Scanner sc=new Scanner(System.in);
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			st=conn.createStatement();
			System.out.println("Enter id to delete record:");
			sid=sc.nextInt();
			String sel="select * from shivanitable where id="+sid;
			rs=st.executeQuery(sel);
			if(rs.next()) {
				String del="delete from shivanitable where id="+sid;
				int retval=st.executeUpdate(del);
				if(retval>0) {
					System.out.println("Record deleted");
				}else {
					System.out.println("Error!! occured");
				}
			}else {
				System.out.println(sid+" not exists");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}


	}


