package com.javaedu;

class ConstructorsClass {
	int id;
	String name;
	
	public ConstructorsClass(int id,String name) {
		this.id=id;
		this.name=name;
	}
	void display() {
		System.out.println("id="+id);
		System.out.println("Name="+name);
	}
}
public class ConstructorWithArguments {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ConstructorsClass ob=new ConstructorsClass(12, "Anushree");
		ob.display();
	}

}
