package com.javaedu;

public class DifferentBlockJavaMain {

	static {
		System.out.println("Static block will execute before main");
	}
	{
		System.out.println("Anonomous block will execute before constructor");
	}
	DifferentBlockJavaMain() {
		System.out.println("Contructor executes after main");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Main Method");
		DifferentBlockJavaMain obj=new DifferentBlockJavaMain();
	}

}
