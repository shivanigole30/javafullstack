package com.javaedu;

class Parent{
	int pid;
	String pname;
	
}
class Child extends Parent{
	int cid;
	String cname;
	public Child() {
		pid=1;
		pname="Kiran";
		cid=4;
		cname="raj";
	}
	void display() {
		System.out.println("Parent name="+pname);
		System.out.println("Child id="+cid);
		System.out.println("Child name="+cname);
	}
}
public class InheritanceMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Child ob=new Child();
		ob.display();
		
	}

}
