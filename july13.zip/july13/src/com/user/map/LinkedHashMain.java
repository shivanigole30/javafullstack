package com.user.map;

import java.util.LinkedHashMap;
import java.util.Map;


public class LinkedHashMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedHashMap<Integer, String> lob=new LinkedHashMap<Integer, String>();
		lob.put(1221, "Kiran");
		lob.put(3212, "Virat");
		lob.put(1100, "Anu");
		lob.put(1101, "Anu");
		lob.put(1221, "Virat");
		System.out.println(lob);
		
		//traversing
		for(Map.Entry<Integer, String> eob:lob.entrySet()){
			System.out.println(eob.getKey()+"\t"+eob.getValue());
		    }
	}
	}


