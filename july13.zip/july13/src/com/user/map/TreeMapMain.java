package com.user.map;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeMap<Integer, String> tob=new TreeMap<Integer, String>();
		tob.put(1221, "Kiran");
		tob.put(3212, "Virat");
		tob.put(1100, "Anu");
		tob.put(1101, "Anu");
		tob.put(1221, "Virat");
		System.out.println(tob);
	

	TreeMap<String, String> tob1=new TreeMap<String, String>();
	tob1.put("A", "Kiran");
	tob1.put("a", "Virat");
	tob1.put("B", "Anu");
	tob1.put("c", "Anu");
	tob1.put("v", "Virat");
	System.out.println(tob1);
	
	//traversing
	
	for(Map.Entry<String, String> eob:tob1.entrySet()){
	System.out.println(eob.getKey()+"\t"+eob.getValue());
    }
}
	}
//A-Z=65to98,a-z=