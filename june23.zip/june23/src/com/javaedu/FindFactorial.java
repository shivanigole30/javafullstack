package com.javaedu;

import java.util.Scanner;

public class FindFactorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i,n;
		double fact=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number:");
		n=sc.nextInt();
		
//		for(i=1;i<=n;i++) {
//			 fact = fact * i;
//			
//		}
		
		i=1;
		while(i<=n) {
			fact=fact*i;
			i++;
		}
		System.out.println("Factorial of " +n+ " is " +fact);
		
	}

}
