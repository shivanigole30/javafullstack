package com.javaedu;

import java.util.Scanner;

public class PrimeNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num,c=0;
		
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		
//		for(i=1;i<=10;i++) {
//			
//			if(num%i==0) {
//				c++;
//			}
//		}
//			if(c==2) {
//				System.out.println("Prime");
//			}
//			else {
//				System.out.println("Not Prime");
//			}
//		}
	
//		boolean prime=true;
//		for(int i=1;i<=10;i++) {
//			 if(num%1==0 && num%num==0) {
//			 prime=true;
//			 break;
//			
//		}
//		}
//		if(prime) {
//			System.out.println("  Prime");
//		}
//		else {
//			System.out.println("Not  Prime");
//		}
//		}
			 boolean prime=true;
				for(int i=2;i<num;i++) {
					if(num%i==0) {
						prime=false;
						break;
					}
				}
				if(prime) {
					System.out.println(num+" is prime");
				}else {
					System.out.println(num+" is not a prime");
				}
	}
}
	



