package com.javaedu;

import java.util.Scanner;

public class FibbonacciSeries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int terms,f1,f2,f3;
		f1=0;
		f2=1;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter terms:");
		terms=sc.nextInt();
		
		
		System.out.println(f1+"\n"+f2);
		
		for(int i=3;i<=terms;i++) {
			f3=f1+f2;
			System.out.println(f3);
			f1=f2;
			f2=f3;
			
		}
	}

}
