package com.user.emp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e1=new Employee(1, "Anu", 35133.3f);
		Employee e2=new Employee(2, "Abhi", 45133.3f);
		Employee e3=new Employee(3, "Shikha", 55133.3f);
		Employee e4=new Employee(4, "Sona", 25133.3f);
		
		ArrayList<Employee> objemp=new ArrayList<Employee>();
		objemp.add(e1);
		objemp.add(e2);
		objemp.add(e3);
		objemp.add(e4);
		System.out.println(objemp);
		
		Iterator<Employee> it=objemp.iterator();
		System.out.println("Eid\tename\tsalary");
		
		while(it.hasNext()) {
			Employee e=it.next();
			System.out.println(e.eid+"\t"+e.ename+"\t"+e.esalary);
		}
		
		//employee salary sorting
		EmployeeSalarySort eobj=new EmployeeSalarySort();
		Collections.sort(objemp,eobj);
		System.out.println("After Sorting Salary");
		Iterator<Employee> eit=objemp.iterator();
     	System.out.println("Eid\tename\tsalary");
		
		while(eit.hasNext()) {
			Employee emp=eit.next();
			System.out.println(emp.eid+"\t"+emp.ename+"\t"+emp.esalary);
	    }
		
		//employee id sorting
		EmployeeIdSort eobj1=new EmployeeIdSort();
		Collections.sort(objemp,eobj1);
		System.out.println("After Sorting Id");
		Iterator<Employee> eit1=objemp.iterator();
     	System.out.println("Eid\tename\tsalary");
		
		while(eit1.hasNext()) {
			Employee emp1=eit1.next();
			System.out.println(emp1.eid+"\t"+emp1.ename+"\t"+emp1.esalary);
	    }
		//employee name sorting
				EmployeeNameSort eobj2=new EmployeeNameSort();
				Collections.sort(objemp,eobj2);
				System.out.println("After Sorting Id");
				Iterator<Employee> eit2=objemp.iterator();
		     	System.out.println("Eid\tename\tsalary");
				
				while(eit2.hasNext()) {
					Employee emp2=eit2.next();
					System.out.println(emp2.eid+"\t"+emp2.ename+"\t"+emp2.esalary);
			    }
		
	}

	
}
