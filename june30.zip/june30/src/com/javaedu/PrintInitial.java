package com.javaedu;

public class PrintInitial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="Vital Information Resource Under Seize";
		String s1="";
		s1=s1+s.charAt(0);
		
		for(int i=0;i<s.length();i++) {
			char ch=s.charAt(i);
			if(ch==' ') {
				s1=s1+s.charAt(i+1);
			}
		}
		
		
		System.out.println(s1);
	}

}
