//method overloading data types
package com.javaedu;

class Overload{
	void display() {
		System.out.println("No args");
	}
	void display(int i) {
		System.out.println("int "+i);
	}
	void display(float i) {
		System.out.println("float "+i);
	}
	void display(double i) {
		System.out.println("double "+i);
	}
	void display(char i) {
		System.out.println("char "+i);
	}
	void display(int i,int j) {
		System.out.println("both int");
	}
	void display(int i,float j) {
	System.out.println("int float");
    }
	void display(float j, int i) {
		System.out.println("float int");
	}
}
public class OverloadFuncDataType {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		Overload obj=new Overload();
		obj.display();
		obj.display(556);
		obj.display(23.3f);
		obj.display('A');
		obj.display(23.40);
		obj.display(23,43);
		obj.display(12, 12.4f);
		obj.display(12.3f, 21);
		
	}

}
