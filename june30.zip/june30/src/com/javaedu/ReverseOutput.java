package com.javaedu;

public class ReverseOutput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="Computer is Fun"; //Fun is Computer
		String b1="";
		
		
//		System.out.println(b1);
		
//		for(int i=s.length()-1;i>=0;i--) {
//			char ch=s.charAt(i);
//			System.out.print(ch);
//		}
		
		
		
		
		String s1="Edubridge";
		StringBuilder sb=new StringBuilder(s1);
		System.out.println(sb.reverse());
		System.out.println(sb.append("India"));
	}

}
//