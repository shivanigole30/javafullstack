package com.javaedu;

import java.util.Scanner;

class ValidateCred extends Exception{
	String username;
	String pass;
	
	
	void inputData() {
		try {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter name");
			username = sc.nextLine();
			System.out.println("Enter pass");
			pass=sc.nextLine();
		}catch(NumberFormatException | NullPointerException e) {
			e.printStackTrace();
		}
	}
	void validateUser() {
		if(username.equals("admin") && pass.equals("admin123")) {
			System.out.println("Valid User");
		}else {
			System.out.println("Invaid");
		}
	}
}
public class StringNullPointer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		 ValidateCred vc=new ValidateCred();
		 vc.inputData();
		 vc.validateUser();
		
	}

}
