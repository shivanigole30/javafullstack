package com.javaedu;
class BankException extends Exception{
	public BankException(String s) {
		super(s);
	}
}
class Bank{
	void checkBalance(int amount){
		if(amount<10000) {
			try {
				BankException bexpt=new BankException("insufficient balance");
				throw bexpt;
			}catch(Exception e) {
				e.printStackTrace();
			}
		}else {
			System.out.println("You can withdraw");
		}
	}
}
public class BankExceptionMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Bank obj=new Bank();
		obj.checkBalance(9999);
	}

}
