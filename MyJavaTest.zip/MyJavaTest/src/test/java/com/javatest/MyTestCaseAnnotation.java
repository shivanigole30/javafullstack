package com.javatest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class MyTestCaseAnnotation {

	@BeforeClass
	public static void  beforeClass() {
		System.out.println("Before Class");
	}
	@Before
	public void beforeTest() {
		System.out.println("before each test");
	}
	@AfterClass
	public static void  afterClass() {
		System.out.println("after class");
	}
	@After
	public void afterTest() {
		System.out.println("after each test");
	}
	@Test
	public void test1() {
		int mul,a,b;
		a=10;
		b=4;
		mul=a*b;
		System.out.println("Test1");
		assertEquals(mul, 40);
		
	}

	@Test
	public void test2() {
		int sub,a,b;
		a=30;
		b=10;
		sub=a-b;
		System.out.println("test2");
		assertEquals(sub,20);
	}
	@Ignore
	public void testIgnore() {
		System.out.println("Partial code, will not be executed");
	}
	@Test(expected=ArithmeticException.class) //exception handling if there is error then only write expected=ArithmeticException.class otherwise don't write. 
	public void divideErr() {
		int a;
		int b=10,c=0;
		a=b/c;
		
	}
}
