//8 july
package com.javatest;

import static org.junit.Assert.*;

import org.junit.Test;

public class EmployeeTestCase {

	@Test
	public void checkstr() {
		String name="anushree";
		assertEquals(name,"anushree");
	}
	@Test
	public void add() {
		int sum;
		int a=10, b=20;
		sum=a+b;
		assertEquals(sum,30);
	}
	@Test
	public void substract() {
		int sub;
		int a=20,b=10;
		sub=a-b;
		assertEquals(sub,10);
	}
//	public static void main(String[] args) {
//		EmployeeTestCase obj=new  EmployeeTestCase(); 
//		obj.checkstr();
//		obj.add();
//		obj.substract();
//	}
	
	
}
