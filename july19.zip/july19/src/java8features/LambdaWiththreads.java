package java8features;

public class LambdaWiththreads {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Runnable rob =()->{
			System.out.println("run method");
		};
		rob.run();
		Thread tob=new Thread(rob);
		tob.start();
	}

}
