package java8features;
interface MyInterfaceone{
	void display(int a, String s);
}
public class MainInterface2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyInterfaceone mob=(a,s)->{
			System.out.println("id "+a+" name "+s);
		};
		mob.display(1, "anu");
	}

}
