package java8features;
interface MyInterface{
	void func();//public abstract
	default void displayInterface() {
		System.out.println("Defalut method in interface");
	}
	static void staticMethodInterface() {
		System.out.println("static method in interface");
	}
}
class MyClass implements MyInterface{

	@Override
	public void func() {
		// TODO Auto-generated method stub
		System.out.println("interface abstract method");
	}
	public void displayInterface() {
		System.out.println("Defalut method in interface");
	}
	static void staticMethodInterface() {
		System.out.println("static method in interface");
	}
}
public class DefaultMethodMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyClass ob=new MyClass();
		ob.displayInterface();
		ob.func();
		MyInterface.staticMethodInterface();
	}

}
