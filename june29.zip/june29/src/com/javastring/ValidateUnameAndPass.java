package com.javastring;

import java.util.Scanner;

public class ValidateUnameAndPass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String un,pass;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter UserName: ");
		un=sc.nextLine();
		System.out.println("Enter Password: ");
		pass=sc.nextLine();
		
		if(un.equalsIgnoreCase("admin")&& pass.equals("admin123")) { //equalsIgnoreCase=case insensitive
			                                                         //equals=case sensitive
			System.out.println("Valid User");
		}else {
			System.out.println("Not Valid User");
		}
	}

}
