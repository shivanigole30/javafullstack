package com.javastring;

public class IndexofName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="Mahatma Karamchandh Gandhi";
		
		int b1=s.indexOf(' ');
		int b2=s.lastIndexOf(' ');
		
		
		System.out.println(s.charAt(0)+"."+s.charAt(b1+1)+"."+s.charAt(b2+1));
//		for(int i=b2+1;i<s.charAt(s.lastIndexOf(s));i++) {
//			System.out.print(i);
//		}
//		
	}

}
