package com.javastring;

import java.util.Scanner;

public class CountWords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any sentence:");
		String s=sc.nextLine();
		int len=s.length();
		int wcount=1;
		
		for(int i=0;i<len;i++) {
			char ch=s.charAt(i);
			if(ch==' ') {
			wcount++;
		}
		
	}
		System.out.println("No. of words in "+s+" is: "+wcount);
}
	}


