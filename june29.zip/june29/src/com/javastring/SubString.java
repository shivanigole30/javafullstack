package com.javastring;

public class SubString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="hello world";
		System.out.println(s.substring(1));
		System.out.println(s.substring(1, 7));
		
		String s1="Mahatma Karamchandh Gandhi";
		System.out.print(s1.charAt(0)+".");
		System.out.print(s1.charAt(s1.indexOf(' ')+1)+".");
		int b2=s1.lastIndexOf(' ')+1;
		System.out.println(s1.substring(b2));
		System.out.println(s1.startsWith("Mahatma"));
		System.out.println(s1.endsWith("Gandhi"));
//		String s2="this";
//		String s3="that";
//		
	}

}
//split functions 