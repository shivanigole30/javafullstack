package com.javaedu;

import java.util.Scanner;

abstract class Shape{
	int width;
	abstract void area();
}
class Square extends Shape{

	Square(int x){
		width=x;
	}
	@Override
	void area() {
		// TODO Auto-generated method stub
		int area=width*width;
		System.out.println("Square"+area);
	}
	
}
class Circle extends Shape{

	Circle(int y){
		width=y;
	}
	@Override
	void area() {
		// TODO Auto-generated method stub
		double area=Math.PI*width;
		System.out.println("Circle"+area);
	}
	
}

public class Program1 {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		int x=sc.nextInt();
		int y=sc.nextInt();
		
		Square a=new Square(x);
		Circle b= new Circle(y);
		a.area();
		b.area();
	}

}
