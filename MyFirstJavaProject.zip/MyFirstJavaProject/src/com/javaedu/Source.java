package com.javaedu;

public class Source {

	
		public static String retString(){

			

			String s ="Parent";

			return s;

			}
		public static void main(String args[]) throws Exception {

			

//			SourceSubClass sub =new SourceSubClass();

			SourceSubClass.retString();


//			Source source=new Source();

			Source.retString();

			

			}

			
}

			

class SourceSubClass extends Source{

	public static String retString(){

		String s1 ="Child";

		

		return s1;
		}
	
			
		
	}


