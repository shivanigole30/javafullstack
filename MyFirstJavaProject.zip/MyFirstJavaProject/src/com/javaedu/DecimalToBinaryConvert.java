package com.javaedu;

import java.util.Scanner;

class Converter{
	public static String toBinary(int x) {
		int count=0,a;
		String binary="";
		int i=0;
		while(x>0) {
			a=x % 2;
			if(a==1) {
				count++;
			}
			binary=a+""+binary;
			x=x/2;
			
		}
		return binary;
	}
}
public class DecimalToBinaryConvert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		int x=sc.nextInt();
		System.out.println(Converter.toBinary(x));
	}

}
