package com.javaedu;
class A{
	static String retString() {
		String s="Parent";
		System.out.println("parent"+s);
		return s;
	}
	
	
}
public class Program extends A{

	static String retString() {
		String s1="Child";
		System.out.println("child"+s1);
		return s1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Program p=new Program();
		Program.retString();
		A a=new A();
		A.retString();
		
		
	}

}
