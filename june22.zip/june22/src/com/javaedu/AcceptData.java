package com.javaedu;

import java.util.Scanner;

public class AcceptData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name;
		int age;
		float salary;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Name:");
		name=sc.nextLine();
		System.out.println("Enter Your Age:");
		age=sc.nextInt();
		System.out.println("Enter Your Salary:");
	    salary=sc.nextFloat();
	    sc.close();
	    
	    System.out.println(" Your Name:"+name+"\n"+"Your Age:"+age+"\n"+"Your Salary:"+salary);
		
		
	}

}
