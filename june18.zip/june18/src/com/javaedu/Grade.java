package com.javaedu;

import java.util.Scanner;

public class Grade {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char grade;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Grade:");
		grade =sc.next().charAt(0);
		
		if(grade=='A') {
			System.out.println("Grade "+grade+" Marks Range from 80-100");
		}
		else if(grade=='B'){
			System.out.println("Grade "+grade+" Marks Range from 60-79");
		}
		else if(grade=='C'){
			System.out.println("Grade "+grade+" Marks Range from 35-59");
		}
		else if(grade=='D'){
		System.out.println("Grade "+grade+" Marks Range from 0-34");
	}
		else {
			System.out.println(" Invalid Grade");
		}

}}
