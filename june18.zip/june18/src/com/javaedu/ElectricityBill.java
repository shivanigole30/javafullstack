package com.javaedu;

import java.util.Scanner;

public class ElectricityBill {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int units;
		float billamount;
		String customer;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name:");
		customer=sc.nextLine();
		System.out.println("Enter Units:");
	    units=sc.nextInt();
	    
	    if(units<=0) {
	    	System.out.println("Units should not be 0  or negative ");
	    	System.exit(0);
	    }
	    if(units>=1 && units <=100) {
	    	billamount=units * 2.00f;
	    	
	
	}
	else if(units>=101 && units<=300) {
		billamount=100*2.00f+(units-100)*3.00f;
		
	}
	else {
		billamount=100*2.0f+(units-200)*3.0f+(units-300)*5.00f;
		billamount=billamount+(billamount)*2.5f/100;
		
	}
	    System.out.println("Name:"+customer);
	    System.out.println("Units:"+units);
	    System.out.println("Billamount:"+billamount);
	

}
}
