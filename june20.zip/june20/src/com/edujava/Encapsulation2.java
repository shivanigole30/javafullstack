package com.edujava;

import java.util.Scanner;

class Student {
	int sid;
	String name;
	float fees;
	
	void inputData() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name");
		name=sc.nextLine();
		System.out.println("Enter Id");
		sid=sc.nextInt();
		System.out.println("Enter Fees");
		fees=sc.nextFloat();
	}
	void displayData() {
		System.out.println("Name="+name);
		System.out.println("Id="+sid);
		System.out.println("Fees="+fees);
	}
	
}
public class Encapsulation2 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Student s1=new Student();
	s1.inputData();
	s1.displayData();
	
	Student s2= new Student();
	s2.inputData();
	s2.displayData();
	
	System.out.println("S1 reference="+s1);
	System.out.println("Name="+s1.name+" ID="+s1.sid+" Fees"+s1.fees);
	
	System.out.println("S2 reference="+s2);
	}

}
