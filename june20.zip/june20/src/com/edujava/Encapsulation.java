package com.edujava;

import java.util.Scanner;

class Circle{
	float area,radius;
	
	void inputData() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Radius:");
		radius=sc.nextFloat();
		
	}
	void calculateArea() {
		float pi=3.14159f;
		area=pi*radius*radius;
	}
	void displayArea() {
		System.out.println("Area of Circle of Radius "+radius+" is "+area);
	}
}
public class Encapsulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Circle cir1=new Circle();
		Circle cir2=new Circle();
		Circle cir3=new Circle();
		
		cir1.inputData();
		cir1.calculateArea();
		cir1.displayArea();
		
		cir2.inputData();
		cir2.calculateArea();
		cir2.displayArea();
		
		cir3.inputData();
		cir3.calculateArea();
		cir3.displayArea();
		
	}

}
