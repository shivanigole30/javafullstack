package com.edujava;

import java.util.Scanner;

public class SwitchCase2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name of the day");
		String day=sc.nextLine();
		
		switch(day){
		
		case "Monday": System.out.println("Day 1 of week");
		     break;
		case "Tuesday": System.out.println("Day 2 of week");
		     break;
		case "Wednesday": System.out.println("Day 3 of week");
		      break;
		case "Thursday": System.out.println("Day 4 of week");
		      break;
		case "Friday": System.out.println("Day 5 of week");
		      break;
		case "Saturday": System.out.println("Day 6 of week");
	      break;
		case "Sunday": System.out.println("Day 7 of week");
	      break;
		
		default: System.out.println("Invalid Input");
		}
	}

}
