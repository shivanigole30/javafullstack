package com.student;

public class student {
	public void display () {
		System.out.println("Welcome to spring framework !!!!");
	}

}
