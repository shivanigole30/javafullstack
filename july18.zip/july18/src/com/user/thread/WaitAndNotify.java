package com.user.thread;
class Bank{
	int amount;
	Bank(){
		amount=1000;
	}
	
synchronized void withDraw(int wamount) throws InterruptedException {
	if(wamount>amount) {
		System.out.println("Insufficient Balance");
	
	System.out.println("First deposit the amount");
	wait();//control
}

   amount=amount-wamount;
   System.out.println("balance amount="+amount);
}
synchronized void deposit(int damount) {
	amount=amount+damount;
	System.out.println("Your amount after deposit="+amount);
    notify();
}
}
public class WaitAndNotify {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Bank bob=new Bank();
		new Thread() {
			public void run() {
				try {
					bob.withDraw(2000);
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
		}.start();
		Thread t2=new Thread() {
			public void run() {
				bob.deposit(2000);
			}
		
		};t2.start();
	

}
}


