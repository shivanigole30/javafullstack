package com.user.thread;
class ThreadOne implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Implements");
		System.out.println(Thread.currentThread());
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
public class ThreadImplements {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		ThreadOne t=new ThreadOne();
		Thread t1=new Thread(t);
		ThreadOne to1=new ThreadOne();
		Thread t2=new Thread(to1);
		t1.setName("t1");
		t1.start();
		t1.join();
		t2.setName("t2");
		t2.start();
	}

}
