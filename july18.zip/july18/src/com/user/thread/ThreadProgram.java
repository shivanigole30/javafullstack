package com.user.thread;
class Thread1 extends Thread{
	
	public void run() {
		
	  	System.out.println("Run method");
	  	System.out.println(Thread.currentThread());
	}
}
class Thread2 extends Thread{
	
	public void run() {
		
	  	System.out.println("Run method two");
	  	System.out.println(Thread.currentThread());
	}
}
public class ThreadProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Thread1 t=new Thread1();
		Thread2 t1=new Thread2();
		t.setName("t1");
		t.setPriority(10);
		t1.setName("t2");
		t1.setPriority(2);
		
		
		t1.start();
		t.start();
		
	}

}
