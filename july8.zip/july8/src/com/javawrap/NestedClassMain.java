package com.javawrap;
class OuterClass{
	int i,j;
	public OuterClass(){
		i=10;
		j=20;
	}
	class InnerClass{
		void innerMethod() {
			System.out.println("Sum="+(i+j));
		}
	}
	void outerMethod() {
		System.out.println("Outer method");
		InnerClass innerob=new InnerClass();
		innerob.innerMethod();
	}
}
public class NestedClassMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 OuterClass obj=new OuterClass();
		 obj.outerMethod();
	}

}
