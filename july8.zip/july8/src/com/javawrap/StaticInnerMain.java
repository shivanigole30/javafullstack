package com.javawrap;
class MyOuterClass{
	int i;
	static int j;
	static class InnerStatic{
		//static method can access only static data
		 void innerFunction() {
			 System.out.println("static class method"+j);
		 }
	}
}


public class StaticInnerMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyOuterClass.InnerStatic ob=new MyOuterClass.InnerStatic();
		ob.innerFunction();
	}

}
