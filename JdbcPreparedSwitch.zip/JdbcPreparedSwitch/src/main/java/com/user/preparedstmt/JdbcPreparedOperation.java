package com.user.preparedstmt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class JdbcPreparedOperation {
	static Connection myconn=null;
	static ResultSet rs=null;
	static PreparedStatement pst=null;
	
	static Scanner sc=new Scanner(System.in);
	
	public static void display() throws SQLException {
		myconn=DatabaseConnectionPrepared.getConnection();
		String sel="select * from shivanitable";
		pst=myconn.prepareStatement(sel);
		rs=pst.executeQuery();
		System.out.println("sid\tsname\tfees");
		while(rs.next()) {
			int id=rs.getInt(1);
			String name=rs.getString(2);
			
			float fees=rs.getFloat(3);
			
			System.out.println(id+"\t"+name+"\t"+fees);
		}
	}
	

	
public static void insert() throws SQLException {
	System.out.println("Enter Id:");
	int id=sc.nextInt();
	System.out.println("Enter Name:");
	String name=sc.next();
	
	System.out.println("Enter Fees:");
	float fees=sc.nextFloat();
	
	myconn=DatabaseConnectionPrepared.getConnection();
	String sel="select * from shivanitable where id =?";
	pst=myconn.prepareStatement(sel);
	pst.setInt(1,id);
	
	rs=pst.executeQuery();
	if(!rs.next()) {
		String ins="insert into shivanitable values(?,?,?)";
		pst=myconn.prepareStatement(ins);
		pst.setInt(1, id);
		pst.setString(2, name);
		
		pst.setFloat(3, fees);
		
		
		int rv=pst.executeUpdate();
		if(rv>0) {
			System.out.println("Record Added");
		}else {
			System.out.println("Error!! Occured");
		}
	}else {
		System.out.println("Already Exists");
	}
}

public static void delete() throws SQLException {
	System.out.println("Enter Id to delete shivanitable record:");
	int id=sc.nextInt();
	myconn=DatabaseConnectionPrepared.getConnection();
	String sel="select * from shivanitable where id=?";
	pst=myconn.prepareStatement(sel);
	pst.setInt(1, id);
	rs=pst.executeQuery();
	if(rs.next()) {
		String del="delete from shivanitable where id=?";
		pst=myconn.prepareStatement(del);
		pst.setInt(1, id);
		
		int rv=pst.executeUpdate();
		if(rv>0) {
			System.out.println("Record Deleted");
		}else {
			System.out.println("Error!! Occured");
		}
	}else {
		System.out.println(id+"Not Exists");
	}
	
}
public static void update() throws SQLException {
	char ch;
	while(true) {
	System.out.println("Enter your choice:");
	System.out.println("1.Update Name");
   	System.out.println("2. Update Fees");
   	
   	
	int choice2=sc.nextInt();
	switch(choice2){
	case 1:
	System.out.println("Enter id to update Name in student record");
	int id=sc.nextInt();
	System.out.println("Enter name to be changed:");
	String name=sc.next();
	myconn=DatabaseConnectionPrepared.getConnection();
	String sel="select * from shivanitable where id=?";
	pst=myconn.prepareStatement(sel);
	pst.setInt(1, id);
	
	rs=pst.executeQuery();
	
	if(rs.next()) {
		String upd="update shivanitable set name=? where id=?";
		pst=myconn.prepareStatement(upd);
		pst.setString(1,name );
		pst.setInt(2, id);

	
    int rv=pst.executeUpdate();
		if(rv>0) {
			System.out.println("Name Updated");
		}else {
			System.out.println("Error occured");
		}
	}else {
		System.out.println("not exists");
	}
	break;
	

	
		
	case 2: System.out.println("Enter Id to Update Fees");
	int id1=sc.nextInt();
	System.out.println("Enter Fees to be change");
	float fees=sc.nextInt();
	myconn=DatabaseConnectionPrepared.getConnection();
	String sel2="select * from shivanitable where id=?";
	pst=myconn.prepareStatement(sel2);
	pst.setInt(1, id1);
	rs=pst.executeQuery();
	if(rs.next()) {
		String upd="update shivanitable set fees=? where id=?";
		pst=myconn.prepareStatement(upd);
		pst.setFloat(1, fees);
		pst.setInt(2, id1);
		
		int rv=pst.executeUpdate();
		if(rv>0) {

			System.out.println("Fees Updated");
		}else {
			System.out.println("Error occured");
		}
	}else {
		System.out.println("not exists");
	}
	break;

	}
	
	
	System.out.println("Enter y to continue or n to terminate");
	ch=sc.next().charAt(0);
		if(ch=='n'||ch=='N') {
			break;
		}


	}
	


	

}
}


