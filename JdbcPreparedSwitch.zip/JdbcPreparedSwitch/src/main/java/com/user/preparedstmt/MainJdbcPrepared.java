package com.user.preparedstmt;

import java.sql.SQLException;
import java.util.Scanner;

public class MainJdbcPrepared {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int choice;
		char ch;
		while(true) {
		System.out.println("***********MENU***********");
		System.out.println("1. Display All Students");
		System.out.println("2. Add Student");
		System.out.println("3. Delete Student based on ID");
		System.out.println("4. Update Student");
		choice=sc.nextInt();
		switch(choice) {
		case 1://display
			System.out.println("All student record");
			JdbcPreparedOperation.display();
			break;
		case 2: //add 
			System.out.println("Insert student record");
			JdbcPreparedOperation.insert();
			break;
		case 3: //delete
			System.out.println("Delete student record");
			JdbcPreparedOperation.delete();
			break;
		case 4: //update
			System.out.println("Update student record");
			JdbcPreparedOperation.update();
			break;
		default: System.out.println("Invalid Input");
		}
		System.out.println("Type y if you want to continue or press n to terminate");
		ch=sc.next().charAt(0);
		if(ch=='n'||ch=='N') 
			break;
		}
		System.out.println("Program is terminated");
	}



	}


