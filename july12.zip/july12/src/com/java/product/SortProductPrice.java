package com.java.product;

import java.util.Comparator;

public class SortProductPrice implements Comparator<Product>{

	@Override
	public int compare(Product o1, Product o2) {
		// TODO Auto-generated method stub
		if(o1.pprice==o2.pprice) {
			return 0;
		}else if(o1.pprice>o2.pprice){
		return 1;
	}else {
		return -1;
	}

	
}
}
