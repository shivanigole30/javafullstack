package com.java.product;

import java.util.Comparator;

public class SortProductName implements Comparator<Product>{

	@Override
	public int compare(Product o1, Product o2) {
		// TODO Auto-generated method stub
		return o1.pname.compareTo(o2.pname);
	}

}
