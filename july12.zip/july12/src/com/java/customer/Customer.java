package com.java.customer;

public class Customer {

	int cid;
	String cname;
	float amt;
	public Customer(int cid, String cname, float amt) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.amt = amt;
	}
	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", cname=" + cname + ", amt=" + amt + "]";
	}
	
}
