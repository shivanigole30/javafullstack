package com.edu.pr;

import java.util.function.Function;

public class FunctionMain {

	public static void main(String[] args) {

       String s="Hello how are you?";
       
       System.out.println("Length of the string="+s.length());
       
             Function<String, Integer> fob=(s1)->s.length();
             
             String s1="Hello how are you?";
             System.out.println("Calls Function use apply(length)"+fob.apply(s1));
             
	}

}


