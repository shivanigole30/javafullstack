package com.javaedu;

public class Print10reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Print 1 to 10 Numbers in reverse order:");
		for(int i=10;i>=1;i--) {
			System.out.println(i);
		}
	}

}
