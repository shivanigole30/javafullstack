package com.edu;

public class MainOperations {

	public static void main(String[] args) {
		

	}

}
