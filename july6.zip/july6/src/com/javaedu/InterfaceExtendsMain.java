package com.javaedu;
interface One{
	void m1();
	
}
interface Two{
	void m2();
}
interface Three extends One,Two{
	void m3();
}
class Child1{
	int sum() {
		return 2+3;
	}
}
class IntClass extends Child1 implements Three,Two, One{

	
	@Override
	public void m1() {
		// TODO Auto-generated method stub
		System.out.println("Interface method m1");
	}

	@Override
	public void m2() {
		// TODO Auto-generated method stub
		System.out.println("Interface method m2");
	}

	@Override
	public void m3() {
		// TODO Auto-generated method stub
		System.out.println("Interface method m3");
	}
	
	
}
public class InterfaceExtendsMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		IntClass obj=new IntClass();
		obj.m1();
		obj.m2();
		obj.m3();
		System.out.println("Sum is: "+obj.sum());
		
	}

}

