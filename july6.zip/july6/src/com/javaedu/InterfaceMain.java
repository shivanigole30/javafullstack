package com.javaedu;
interface MyInterface{
	int val=10; //public static final
	void interfaceMethod1(); //public abstract 
	void interfaceMethod2();
}
/*in the interface
-->all the variables are by default public static and final
--> methods or functions are by default public abstract

in java a class can implement any no of interfaces 
but a class extends only one class 
ex: class A extends Singleclass implements intf1, intf2,...{}
through interface we can acheive multiple inheritance 
one interface can extends any number of interface 
ex: interface interface_name extends intf1,intf2...{}
 */
class MyClass implements MyInterface{

	@Override
	public void interfaceMethod1() {
		// TODO Auto-generated method stub
		System.out.println("hello interfaceMethod1");
	}

	@Override
	public void interfaceMethod2() {
		// TODO Auto-generated method stub
		System.out.println("hello interfaceMethod2");
	}
	//you have to override all the methods of the interface otherwise make the class as abstract
}
public class InterfaceMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyClass obj=new MyClass();
		obj.interfaceMethod1();
		obj.interfaceMethod2();
	}

}
