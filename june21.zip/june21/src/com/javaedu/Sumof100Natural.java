package com.javaedu;

public class Sumof100Natural {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=1;
		int sum=0;
		while(i<=100) {
			
			sum=sum+i;
			i++;
		}
		System.out.println("Sum is "+sum);
	}

}
