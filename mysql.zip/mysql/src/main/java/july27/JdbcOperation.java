package july27;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class JdbcOperation {

private static Connection myconn;
	private static Statement st;
	private static ResultSet rs;
	public static void displayStudent() throws SQLException{
		myconn=DatabaseConnection.getConnection();
		st=myconn.createStatement();
		String sel="select * from shivanitable";
		rs=st.executeQuery(sel);
		System.out.println("sid\tsn\tfs");
		while(rs.next()) {
			int sid=rs.getInt(1);
			String sn=rs.getString(2);
			float fs=rs.getFloat(3);
			System.out.println(sid+"\t"+sn+"\t"+"\t"+fs);
		}
	}
	
	public static void addStudent() throws SQLException {
		myconn=DatabaseConnection.getConnection();
		st=myconn.createStatement();
		
		int sid;
		String sn;
		float fs;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter student name");
		sn=sc.next();
		System.out.println("Enter Student id");
		sid=sc.nextInt();
		System.out.println("Enter student fees");
		fs=sc.nextFloat();
		
		try {
			
			//check record exists
			String sel="select * from shivanitable where id="+sid;
			rs=st.executeQuery(sel);
			if(rs.next()){
				System.out.println(sid+" already exists");
			}else {
			
			
			String ins="insert into shivanitable values("+sid+",'"+sn+"',"+fs+")";
//			System.out.println(ins);
			int rval=st.executeUpdate(ins);//for insert , update and delete use exceuteUpdate
			if(rval>0) {
				System.out.println("Record is added");
			}
			else {
				System.out.println("Error Occurred");
			}
			}
			
	}catch(Exception e) {
		e.printStackTrace();
	}
	}
	public static void deleteStudent() throws SQLException {
		myconn=DatabaseConnection.getConnection();
		st=myconn.createStatement();
		int sid;
		Scanner sc=new Scanner(System.in);
		try {
			
			System.out.println("Enter id to delete record:");
			sid=sc.nextInt();
			String sel="select * from shivanitable where id="+sid;
			rs=st.executeQuery(sel);
			if(rs.next()) {
				String del="delete from shivanitable where id="+sid;
				int retval=st.executeUpdate(del);
				if(retval>0) {
					System.out.println("Record deleted");
				}else {
					System.out.println("Error!! occured");
				}
			}else {
				System.out.println(sid+" not exists");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void updateStudent() throws SQLException {
		myconn=DatabaseConnection.getConnection();
		st=myconn.createStatement();
		String n;
		int stid;
		Scanner sc=new Scanner(System.in);
		
		try {
			
			System.out.println("Enter name to be changed");
			n=sc.nextLine();
			System.out.println("Enter student id:");
			stid=sc.nextInt();
			//check id exists for updating record
			
			String sel="select * from shivanitable where id="+stid;
			rs=st.executeQuery(sel);
			if(rs.next()) {
				String upd="update shivanitable set name='"+n+"' where id ="+stid;
				int retval=st.executeUpdate(upd);
				if(retval>0) {
					System.out.println("student changed successfully");
				}else {
					System.out.println("error!!!");
				}
			}else {
				System.out.println(stid+" not exists for updating record");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
