package CoddingAssesment;
import java.util.Scanner;

public class LargestOfTwo {

	public static void main(String[]args)
	{
		
		int number1, number2;
		Scanner sc=new Scanner (System.in);
		System.out.println("Please Enter The First Number:");
		number1 = sc.nextInt();
		System.out.println("Please Enter The Second Number:");
		number2 = sc.nextInt();
		
		if(number1> number2)
		{
			System.out.println("\n The Largest Number=" + number1);
		}
		else if (number2> number1)
		{
			System.out.println("\n The Largest Number = " + number2);
		}
		else
		{
			System.out.println("\n Both are Equal");
			
		}
	}

}
