package CoddingAssesment;
import java.util.Scanner;


public class FindFactorial {
	
		
		int i,n;
		double fact=1;
		public void inputData() {
		Scanner sc= new Scanner (System.in);
		System.out.println("Enter Number:");
		
		n=sc.nextInt();
		}
		public void factorial() {
		
		for(i=1;i<=n;i++) {
			fact = fact * i ;
		}
		
		System.out.println("Factorial of " +n+" is "+fact);
		}
		
	}





