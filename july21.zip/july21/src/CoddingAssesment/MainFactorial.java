package CoddingAssesment;

public class MainFactorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FindFactorial fi=new FindFactorial();
		fi.inputData();
		fi.factorial();
		

	}

}
