package CoddingAssesment; 
class Prime{
 void generatePrime() {
	int c=0;

	   for(int i=1; i<=100;i=i+2){ 
	           c=0;
	           for(int j=1;j<=i;j++){
	                   if(i%j==0){
	                       c++; 
	                  }
	           }
	          if(c==2){
	              System.out.print(i+" ");
	         }
	  }
}
}
	   public class GeneratePrime{ 
		   public static void main(String args[]){
			    Prime ob=new Prime();
			    ob.generatePrime();
			    
		   
}
}
