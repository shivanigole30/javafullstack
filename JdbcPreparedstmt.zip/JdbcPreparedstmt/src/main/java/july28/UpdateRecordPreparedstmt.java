package july28;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class UpdateRecordPreparedstmt {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String driver ="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/shivani";
		String un="root";
		String up="root";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		
		String n;
		int stid;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter student id:");
		stid=sc.nextInt();
		System.out.println("Enter name to be changed");
		n=sc.next();
		
		
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			String sel="select * from shivanitable where id=?";
			pst=conn.prepareStatement(sel);
			pst.setInt(1, stid);
			
			rs=pst.executeQuery();
			if(rs.next()) {
				String upd="update shivanitable set name=? where id =?";
				pst=conn.prepareStatement(upd);
				pst.setString(1, n);
				pst.setInt(2, stid);
int retval=pst.executeUpdate();
				
				if(retval>0) {
					System.out.println("student changed successfully");
				}else {
					System.out.println("error!!!");
				}
			}else {
				System.out.println(stid+" not exists for updating record");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}


}
