package july28;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MainPrepared {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String driver ="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/shivani";
		String un="root";
		String up="root";
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			String sel="select * from shivanitable";
			pst=conn.prepareStatement(sel);
			System.out.println();
			rs=pst.executeQuery();
			System.out.println("sid\tname\tfees");
			while(rs.next()) {
				
				int id=rs.getInt(1);
				String n=rs.getString(2);
				float f=rs.getFloat(3);
				System.out.println(id+"\t"+n+"\t"+f);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}


}
