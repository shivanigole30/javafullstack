package july28;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class DeletePreparedMain {
public static void main(String[] args) {
	String driver ="com.mysql.cj.jdbc.Driver";
	String url="jdbc:mysql://localhost:3306/shivani";
	String un="root";
	String up="root";
	int sid;
	PreparedStatement pst=null;
	Connection conn=null;
	ResultSet rs=null;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter student id to delete record:");
	int stid=sc.nextInt();
	try {
		Class.forName(driver);
		conn=DriverManager.getConnection(url,un,up);
		String sel="select * from shivanitable where id=?";
		pst=conn.prepareStatement(sel);
		pst.setInt(1, stid);
		
		rs=pst.executeQuery();
		if(rs.next()) {
			String del="delete from shivanitable where id=?";
			pst=conn.prepareStatement(del);
			pst.setInt(1, stid);
			int retval=pst.executeUpdate();
			if(retval>0) {
				System.out.println("Record deleted");
			}else {
				System.out.println("Error!! occured");
			}
		}else {
			System.out.println(stid+" not exists");
		}
	}catch(Exception e){
		e.printStackTrace();
	}

}

}
