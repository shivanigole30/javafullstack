package july28;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class PreparedStatementInsert {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
String driver="com.mysql.cj.jdbc.Driver";//Driver class
String url="jdbc:mysql://localhost:3306/shivani";
String un="root";
String up="root";
Connection conn=null;
PreparedStatement pst=null;
ResultSet  rs=null;
int sid,cid;
String name;
float fees;
try {
	Class.forName(driver);
	conn=DriverManager.getConnection(url,un,up);
	
}catch(Exception e) {
	e.printStackTrace();
}
Scanner sc=new Scanner(System.in);
System.out.println("Enter name");
String n=sc.next();
System.out.println("Enter id");
sid=sc.nextInt();
System.out.println("Enter fees");
fees=sc.nextFloat();
//check sid exists
String sel="select * from shivanitable where id=?";
pst=conn.prepareStatement(sel);

pst.setInt(1, sid);
rs=pst.executeQuery();
if(!rs.next()) {
	String ins="insert into shivanitable values(?,?,?)";
	pst=conn.prepareStatement(ins);
	pst.setInt(1, sid);
	pst.setString(2, n);
	pst.setFloat(3, fees);
	
	
	int rv=pst.executeUpdate();
	if(rv>0) {
		System.out.println("Student record is added");
	}else {
		System.out.println("Error occured");
	}
	}else {
		System.out.println(sid+" already exists ");
	}



	}

}
