package com.edu;

import java.util.Scanner;

class Reverse{
	int rev;
	int num,d;
	
	void inputData() {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Num:");
	num=sc.nextInt();
	}
	
	void displayData() {
		while(num!=0) {
			d=num%10;
			rev=rev*10+d;
			num=num/10;
		}
		System.out.println(rev);
	
	
}
}

public class ReverseNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Reverse i1=new Reverse();
		i1.inputData();
		i1.displayData();
		
	}

}
