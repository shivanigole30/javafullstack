package com.edu;

import java.util.Scanner;

public class LargestofTwoNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num1,num2;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter First Number:");
		num1=sc.nextInt();
		System.out.println("Enter Second Number:");
		num2=sc.nextInt();
		
		if(num1>num2) {
			System.out.println(num1+" is largest");
		}
		else if(num1==num2) {
			System.out.println("Both are equal");
		}
		else {
			System.out.println(num2+" is largest");
		}
	}

}
