package com.user.thread;
class PrintTable{
	synchronized void displayTable(int n){
		for(int i=1;i<=10;i++) {
			System.out.println(n+"x"+i+"="+(n*i));
		}
		
}
}
class Thread1 extends Thread{
	PrintTable tob;
	public Thread1(PrintTable t) {
		this.tob=t;
	}
	public void run() {
		tob.displayTable(6);
	}
}
class Thread2 extends Thread{
	PrintTable tob1;
	public Thread2(PrintTable t) {
		this.tob1=t;
	}
	public void run() {
		tob1.displayTable(2);
	}
}

public class ThreadMainToPrintTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PrintTable t=new PrintTable();
		Thread1 t1=new Thread1(t);
		Thread2 t2=new Thread2(t);
		
		t1.start();
		
		t2.start();
	}

}
