package com.user.thread;
class FirstClass implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<=5;i++) {
			System.out.println(Thread.currentThread()+"i"+i);
		}
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
public class ThreadImplementsRunnable {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		FirstClass obj=new FirstClass();
		FirstClass obj2=new FirstClass();
		Thread tob=new Thread(obj);
		Thread tobj=new Thread(obj2);
		tob.setName("first");
		tobj.setName("second");
		System.out.println(tob+"is alive "+tob.isAlive());
		tob.start();
		System.out.println(tob+"is alive "+tob.isAlive());
		tob.join();
		System.out.println(tobj+"is alive "+tobj.isAlive());
		tobj.start();
	}

}
