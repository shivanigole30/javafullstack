package com.java.practice;

import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class TreeMapMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeMap<String,Integer> tm=new TreeMap<String,Integer>();
		Scanner sc=new Scanner(System.in);
		System.out.println("how many entries");
		int num=sc.nextInt();
		for(int i=0;i<num;i++) {
			int s1=sc.nextInt();
			String s2=sc.nextLine();
			tm.put(s2, s1);
		}
	   for(Map.Entry<String,Integer> eob:tm.entrySet())
	   System.out.println(eob.getKey()+"\t"+eob.getValue());

}
}
