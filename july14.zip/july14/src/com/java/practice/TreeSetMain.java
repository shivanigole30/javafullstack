package com.java.practice;

import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class TreeSetMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeSet<String> tst=new TreeSet<String>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many no.");
		int num=sc.nextInt();
		for(int i=0;i<=num;i++) {
			String value=sc.nextLine();
			tst.add(value);
			
		}
		Iterator<String> it=tst.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
	}

}
