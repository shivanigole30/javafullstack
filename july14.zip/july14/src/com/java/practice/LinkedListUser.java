package com.java.practice;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class LinkedListUser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedList<Integer> lob=new LinkedList<Integer>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number:");
		int num=sc.nextInt();
		for(int i=0;i<=num;i++) {
			int value=sc.nextInt();
			lob.add(value);
		}
		
		
		Iterator<Integer> it=lob.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
