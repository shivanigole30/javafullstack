package july29;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class EmployeeOperation {
	static Connection myconn=null;
	static ResultSet rs=null;
	static PreparedStatement pst=null;
	
	static Scanner sc=new Scanner(System.in);
	
	public static void display() throws SQLException {
		myconn=EmployeeConnection.getConnection();
		String sel="select * from employee";
		pst=myconn.prepareStatement(sel);
		rs=pst.executeQuery();
		System.out.println("eid\tename\teage\tesalary\teemail");
		while(rs.next()) {
			int id=rs.getInt(1);
			String name=rs.getString(2);
			int age=rs.getInt(3);
			float sal=rs.getFloat(4);
			String email=rs.getString(5);
			System.out.println(id+"\t"+name+"\t"+age+"\t"+sal+"\t"+email);
		}
	}
	
	public static void insert() throws SQLException {
		System.out.println("Enter Id:");
		int id=sc.nextInt();
		System.out.println("Enter Name:");
		String name=sc.next();
		System.out.println("Enter Age:");
		int age=sc.nextInt();
		System.out.println("Enter Salary:");
		float sal=sc.nextFloat();
		System.out.println("Enter Unique Email ID");
		String email=sc.next();
		myconn=EmployeeConnection.getConnection();
		String sel="select * from employee where eid =?";
		pst=myconn.prepareStatement(sel);
		pst.setInt(1,id);
		
		rs=pst.executeQuery();
		if(!rs.next()) {
			String ins="insert into employee values(?,?,?,?,?)";
			pst=myconn.prepareStatement(ins);
			pst.setInt(1, id);
			pst.setString(2, name);
			pst.setInt(3, age);
			pst.setFloat(4, sal);
			pst.setString(5, email);
			
			int rv=pst.executeUpdate();
			if(rv>0) {
				System.out.println("Record Added");
			}else {
				System.out.println("Error!! Occured");
			}
		}else {
			System.out.println("Already Exists");
		}
	}
	
	public static void delete() throws SQLException {
		System.out.println("Enter Id to delete employee record:");
		int id=sc.nextInt();
		myconn=EmployeeConnection.getConnection();
		String sel="select * from employee where eid=?";
		pst=myconn.prepareStatement(sel);
		pst.setInt(1, id);
		rs=pst.executeQuery();
		if(rs.next()) {
			String del="delete from employee where eid=?";
			pst=myconn.prepareStatement(del);
			pst.setInt(1, id);
			
			int rv=pst.executeUpdate();
			if(rv>0) {
				System.out.println("Record Deleted");
			}else {
				System.out.println("Error!! Occured");
			}
		}else {
			System.out.println(id+"Not Exists");
		}
		
	}
	public static void update() throws SQLException {
		char ch;
		while(true) {
		System.out.println("Enter your choice:");
		System.out.println("1.Update Name");
       	System.out.println("2. Update Age");
       	System.out.println("3. Update Salary");
       	System.out.println("4. Update Email");
		int choice2=sc.nextInt();
		switch(choice2){
		case 1:
		System.out.println("Enter id to update Name in Employee record");
		int id=sc.nextInt();
		System.out.println("Enter name to be changed:");
		String name=sc.next();
		myconn=EmployeeConnection.getConnection();
		String sel="select * from employee where eid=?";
		pst=myconn.prepareStatement(sel);
		pst.setInt(1, id);
		
		rs=pst.executeQuery();
		
		if(rs.next()) {
			String upd="update employee set ename=? where eid=?";
			pst=myconn.prepareStatement(upd);
			pst.setString(1,name );
			pst.setInt(2, id);
			
			
			int rv=pst.executeUpdate();
			if(rv>0) {
				System.out.println("Name Updated");
			}else {
				System.out.println("Error occured");
			}
		}else {
			System.out.println("not exists");
		}
		break;
		case 2: 
			System.out.println("Enter Id to update age in employee record:");
			id=sc.nextInt();
			System.out.println("Enter age to be change");
			int age=sc.nextInt();
			myconn=EmployeeConnection.getConnection();
			String sel1="select * from employee where eid=?";
			pst=myconn.prepareStatement(sel1);
			pst.setInt(1, id);
			rs=pst.executeQuery();
			if(rs.next()) {
				String upd="update employee set eage=? where eid=?";
				pst=myconn.prepareStatement(upd);
				pst.setInt(1, age);
				pst.setInt(2, id);
				
				int rv=pst.executeUpdate();
				if(rv>0) {
					System.out.println("Age Updated");
				}else {
					System.out.println("error !!!");
				}
				
			}else {
				System.out.println("not exists");
			}
			break;
			
		case 3: System.out.println("Enter Id to Update Salary");
		id=sc.nextInt();
		System.out.println("Enter Salary to be change");
		int sal=sc.nextInt();
		myconn=EmployeeConnection.getConnection();
		String sel2="select * from employee where eid=?";
		pst=myconn.prepareStatement(sel2);
		pst.setInt(1, id);
		rs=pst.executeQuery();
		if(rs.next()) {
			String upd="update employee set esalary=? where eid=?";
			pst=myconn.prepareStatement(upd);
			pst.setInt(1, sal);
			pst.setInt(2, id);
			
			int rv=pst.executeUpdate();
			if(rv>0) {
				System.out.println("Salary Updated");
			}else {
				System.out.println("error !!!");
			}
			
		}else {
			System.out.println("not exists");
		}
		break;
		
		case 4:
			System.out.println("Enter id to update email");
			id=sc.nextInt();
			System.out.println("Enter email to be change");
			String mail=sc.next();
			myconn=EmployeeConnection.getConnection();
			String sel3="select * from employee where eid=?";
			pst=myconn.prepareStatement(sel3);
			pst.setInt(1, id);
			rs=pst.executeQuery();
			if(rs.next()) {
				String upd="update employee set eemail=? where eid=?";
				pst=myconn.prepareStatement(upd);
				pst.setString(1, mail);
				pst.setInt(2, id);
				
				int rv=pst.executeUpdate();
				if(rv>0) {
					System.out.println("Mail Updated");
				}else {
					System.out.println("error !!!");
				}
				
			}else {
				System.out.println("not exists");
			}
			break;
		}
		System.out.println("Enter y to continue or n to terminate");
		ch=sc.next().charAt(0);
			if(ch=='n'||ch=='N') {
				break;
			}
	}
	}

	
}
